import numpy as np
import scipy.stats as stats
from math import sqrt
from contract import *

def bsm_call(option,rfr=0.06,price=100,vol=0.15/sqrt(260),div=0):
    T=option.T
    strike=option.strike
    N=stats.norm.cdf
    d1=(np.log(price/strike)+(rfr-div+vol**2/2)*T)/(vol*np.sqrt(T))
    d2=d1-vol*np.sqrt(T)
    call = price*np.exp(-div*T)*N(d1)-strike*np.exp(-rfr*T)*N(d2)
    delta=-np.exp(-div*T)*N(-d1)
    return call,delta   

def bsm_put(option,rfr=0.06,price=100,vol=0.15/sqrt(260),div=0):
    T=option.T
    strike=option.strike
    N=stats.norm.cdf
    d1=(np.log(price/strike)+(rfr-div+vol**2/2)*T)/(vol*np.sqrt(T))
    d2=d1-vol*np.sqrt(T)
    put = strike*np.exp(-rfr*T)*N(-d2)-price*np.exp(-div*T)*N(-d1)
    delta=-np.exp(-div*T)*N(-d1)
    return put,delta