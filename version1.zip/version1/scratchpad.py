import numpy as np
from math import sqrt

a=np.arange(1,10,1)
print(a[1:])
